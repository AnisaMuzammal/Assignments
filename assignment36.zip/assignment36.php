<!-- Write a PHP function that checks whether a string is all lowercase. -->
<?php
$str= "laravel";
print(ctype_lower($str));
if (ctype_lower($str)){
    echo "all lower case";
}
// if (ctype_upper($str)){
//     echo "all uppercase";
// }
else {
    echo "not in lower case";
}
?>