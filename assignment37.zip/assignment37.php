<!-- Write a PHP program to find the length of the string. -->
<?php
$str= "Anisa Muzammal";
echo strlen($str);
?>