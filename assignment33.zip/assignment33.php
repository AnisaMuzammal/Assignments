<!-- Write a Program to display count, from 1 to 5 using PHP do...while loop as given below:
1
2
3
4
5 -->
<?php
$i=1;
do{
    echo"$i <br>";
    $i++;
}while ($i<=5);
?>