<!-- ///////////////////////// Use of If…else Condition ////////////////////////////
// Use the If...else statement of PHP to write a code to Display“Good Morning” or “Good Afternoon” 
// according to current time -->
<?php
$currentstatus = date("D");
if ($currentstatus < "12") {
    echo "Good Morning";
}
else{
    echo "Good Afternoon";
}
?>
