<!-- Use of Switch Statement
Use the Switch statement of PHP to display the current day of the week -->
<?php
$currentDay = date('N');
switch ($currentDay){
    case 1;
    echo "Today is Sunday.";
    break;
    case 2;
    echo "Today is Monday.";
    break;
    case 3;
    echo "Today is Tuesday.";
    break;
    case 4;
    echo "Today is Wednesday.";
    break;
    case 5;
    echo "Today is Thursday.";
    break;
    case 6;
    echo "Today is Friday.";
    break;
    case 7;
    echo "Today is Saturday.";
    break;
    default:
    echo "Unable to determine the day of the week.";
    break;
}
?>