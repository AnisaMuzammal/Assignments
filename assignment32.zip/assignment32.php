<?php
// Write a Program to create following pattern using while 
// loop:
// *
// **
// ***
// ****
// *****
// ******
// *******
// ********
$rows= 8;
$cols = 8;

$row =0;
while($row <= $rows) {
   $col = 0;

   while($col<= $row){
    echo "*";
    $col ++;
   }
   echo "<br>";
   $row++;
}
?>

