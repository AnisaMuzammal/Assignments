<!-- Write a function to sort an array  -->
<?php
  // sort array in ascending alphabetical order:
// $fruits = array("Mango","Banana","gava");
// sort($fruits);
// print_r($fruits);

// sort array in  descending alphabetical order
// $fruits = array("Mango","Banana","gava");
// rsort($fruits);
// print_r($fruits);

// sort numbers array in descending numerical order:
    // $numbers = array (10,8,9,5,7,4,3,6,2,1);
    // rsort($numbers);
    // print_r($numbers);
// sorts an associative array in ascending order, according to the value:
    // $age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
    // asort($age);
    // print_r($age);
//associative array in ascending order, according to the key:
    $age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
    ksort($age);
    print_r($age);
?>