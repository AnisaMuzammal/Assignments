<?php
// Loops to display numbers on screen
// Write a Program to display count, from 5 to 15 (as shown below) using following:
// • For Loop
// • While Loop
// • Do…while Loop
/////////////////////////////For loop////////////////////////////////////
for($i=5; $i<=15; $i++){
    echo"The Number is: $i <br>";
}

////////////////////////////Do while Loop///////////////////////////////
// $i=5;
// do {
//     echo "The Number  is: $i <br>";
//     $i++;
// } while ($i <= 15);

/////////////////////////// while loop////////////////////////////
// $i=5;
// while($i<=15) {
//     echo "The Number is: $i <br>";
//     $i++;
// }

?>