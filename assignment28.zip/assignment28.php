 <!-- Use Output Statement of PHP
Display your name on the screen using PHP. -->
<?php
$name="Anisa";
echo $name;
?>