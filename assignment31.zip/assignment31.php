<?php
// Write a program to calculate factorial of a number using for
// loop in PHP.
$number = 5;
$factorial = 1;

for ( $i=1; $i<=$number; $i++){
    $factorial *= $i;
}
echo "The factorial of $number is: $factorial";
?>